import { useState } from 'react';
import { useAppContext } from './AppProvider';
import Cliente from './Cliente';
import Servicio from './Servicio';

export default function Vehiculo () {
  const { dispatch } = useAppContext();

  const [marca, setMarca] = useState('');
  const [modelo, setModelo] = useState('');
  const [placa, setPlaca] = useState('');
  const [gasolina, setGasolina] = useState('');
  const [defectos, SetDefectos] = useState('');
  const [mostrarComponente, setMostrarComponente] = useState('vehiculo');
  let botonName = 'vehiculo';

  const handleSubmit = (e) => {
    e.preventDefault();
    //console.log({nombres, email, celular, identificacionFiscal, tidpid})
    const vehiculo = { 
      marca, 
      modelo, 
      placa, 
      gasolina, 
      defectos
    };
    //console.log(cliente); 
    dispatch({
        type: 'ADD_VEHICULO',
        value: vehiculo
    });
    //console.log(botonName);
    setMostrarComponente(botonName);
  }

  const verBoton = (boton) => {
    botonName  = boton;
  };  


  if(mostrarComponente === 'servicio') {
    return (<div> <Servicio /> </div>);
  }
  else{ 
    if (mostrarComponente === 'cliente') {
      return (<div> <Cliente /> </div>);
    }
  }
  
return (
    <form className='form-react' onSubmit={handleSubmit}>
        <h2>Datos del Vehiculo</h2>
        <div className='form-control'>
            <label htmlFor="marca">Marca</label>
            <input 
              type="text" 
              id="marca" 
              placeholder=""
              onChange={(e)=> setMarca(e.target.value)}
            />
        </div>
        <div className='form-control'>
            <label htmlFor="modelo">Modelo</label>
            <input 
              type="text" 
              id="modelo" 
              placeholder=""
              onChange={(e)=> setModelo(e.target.value)}
            />
        </div>
        <div className='form-control'>
            <label htmlFor="placa">Placa</label>
            <input 
              type="text" 
              id="placa" 
              placeholder=""
              onChange={(e)=> setPlaca(e.target.value)}
            />
        </div>
        <div className='form-control'>
            <label htmlFor="gasolina">Nivel Tanque Gasolina</label>
            <input 
              type="text" 
              id="gasolina" 
              placeholder=""
              onChange={(e)=> setGasolina(e.target.value)}
            />
        </div>
        <div className='form-control'>
            <label htmlFor="detalle">Datos Exterior del Vehiculo</label>
            <input 
              type="text" 
              id="detalle" 
              placeholder=""
              onChange={(e)=> SetDefectos(e.target.value)}
            />
        </div>

        <div className='form-control'>
            <button type="submit" name='cliente' onClick={(e)=> verBoton (e.target.name)}> {'<<=='}Regresar </button>
            <hr color='black'/>
            <button type="submit" name='servicio' onClick={(e)=> verBoton (e.target.name)}>Siguiente{'==>>'} </button>
        </div>   
    </form>
    );
}