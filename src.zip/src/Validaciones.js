

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("formcliente").addEventListener('submit', validarFormularioCliente); 
  });
  
  function validarFormularioCliente(evento) {
    evento.preventDefault();
    var nombres = document.getElementById('nombre').value;
    if(usuario.length == 0) {
      alert('Nombre del Cliente campo obligatorio');
      return;
    }
    var email = document.getElementById('email').value;
    if (email.length == 0) {
      alert('Email del Cliente campo obligatorio');
      return;
    }
    var celular = document.getElementById('celular').value;
    if (celular.length == 0) {
      alert('Celular del Cliente campo obligatorio');
      return;
    }    
    var identificacion = document.getElementById('identificacion').value;
    if (identificacion.length == 0) {
      alert('Identificacion Fiscal del Cliente campo obligatorio');
      return;
    }    
    this.submit();
}