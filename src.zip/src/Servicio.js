import { useState } from 'react';
import { useAppContext } from './AppProvider';
import Vehiculo from './Vehiculo';
import Orden from './Orden';

export default function Servicio () {
  const { dispatch } = useAppContext();

  const [aceite, setAceite] = useState('');
  const [frenos, setFrenos] = useState('');
  const [balanceo, setBalanceo] = useState('');
  const [diagnostico, setDiagnostico] = useState('');
  const [electrica, SetElectrica] = useState('');
  const [suspension, Setsuspension] = useState('');
  const [mostrarComponente, setMostrarComponente] = useState('servicio');
  let botonName = 'servicio';

  const handleSubmit = (e) => {
    e.preventDefault();
    //console.log({nombres, email, celular, identificacionFiscal, tidpid})
   const servicio = { 
      aceite, 
      frenos, 
      balanceo, 
      diagnostico, 
      electrica,
      suspension
    };
    //console.log(cliente); 
    dispatch({
        type: 'ADD_SERVICIO',
        value: servicio
    });
    //console.log(botonName);
    setMostrarComponente(botonName);    
  }

  const verBoton = (boton) => {
    botonName  = boton;
  };  


if(mostrarComponente === 'vehiculo') {
  return (<div> <Vehiculo /> </div>);
}
else{ 
  if (mostrarComponente === 'orden') {
    return (<div> <Orden /> </div>);
  }
}


return (
        <form className='form-react' onSubmit={handleSubmit}>
          <h2>Tipo de Servicios</h2>
          <div className='form-react'>
              <label for="tiposervicio">Seleccione el tipo de servicio a realizar:</label>
              <div class="linea">
                <input type="checkbox" 
                  name="aceite" 
                  id="aceite"
                  onChange={(e)=> setAceite( (e.target.checked) ? "Cambio de aceite" : '')}
                />
                <label for="aceite">Cambio de aceite</label>
              </div>
              <div class="linea">
                <input 
                  type="checkbox" 
                  name="frenos" 
                  id="frenos"
                  onChange={(e)=> setFrenos( (e.target.checked) ? "Cambio de frenos" : '')}
                />
                <label for="frenos">Cambio de frenos</label>
              </div>

              <div class="linea">
                <input 
                  type="checkbox" 
                  name="balanceo" 
                  id="balanceo"
                  onChange={(e)=> setBalanceo( (e.target.checked) ? "Alineación y balanceo" : '')}
                />
                <label for="balanceo">Alineación y balanceo</label>  
              </div>

              <div class="linea">
                <input 
                  type="checkbox" 
                  name="diagnostico" 
                  id="diagnostico"
                  onChange={(e)=> setDiagnostico( (e.target.checked) ? "Diagnóstico general" : '')}
                />
                <label for="diagnostico">Diagnóstico general</label>  

              </div>
              <div class="linea">
                <input 
                  type="checkbox" 
                  name="electrica" 
                  id="electrica"
                  onChange={(e)=> SetElectrica( (e.target.checked) ? "Revisión sistema eléctrica" : '')}
                  />
                <label for="electrica">Revisión sistema eléctrica</label>  
              </div>

              <div class="linea">
                <input 
                  type="checkbox" 
                  name="suspension" 
                  id="suspension"
                  onChange={(e)=> Setsuspension( (e.target.checked) ? ">Revisión de la suspensión" : '')}
                />
                <label for="suspension">Revisión de la suspensión</label>  
              </div>              
          </div> 
          <div className='form-control'>
            <button type="submit" name='vehiculo' onClick={(e)=> verBoton (e.target.name)}> {'<<=='}Regresar </button>
            <hr color='black'/>
            <button type="submit" name='orden' onClick={(e)=> verBoton (e.target.name)}>Generar orden{'==>>'} </button>
         </div>   

        </form>
    );
}