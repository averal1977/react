import Cliente from './Cliente';
import './App.css';
import AppProvider from './AppProvider';



const App = () => {

  return (
    <AppProvider>
      <div className="App">
      <h1>TALLER AUTOMOTRIZ ALEX VERA & ASOCIADOS</h1>  
        <Cliente />
      </div>
    </AppProvider>
  );
}

export default App;