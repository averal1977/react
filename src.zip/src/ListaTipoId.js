const tipoId = ['Cédula', 'Ruc', 'Pasaporte']
 
export default function ListaTipoId({ children }) {
   return (
   <div>    
     { children }
     <div className='caja'>
        <select id='tipo_id'>
        {tipoId.map(item => (
            <Items item={item}
            />
        ))}
        </select>
     </div>
   </div>
   );
 }
 export function Items({item}) {
    return (
      <option value={item}>{item}</option>
    );
  }