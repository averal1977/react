//import { useState } from 'react';
import { useAppContext } from "./AppProvider";
import Cliente from "./Cliente";

export default function Orden () {
    const {cliente} = useAppContext();
    const {vehiculo} = useAppContext();
    const {servicio} = useAppContext();
    //const [mostrarComponente, setMostrarComponente] = useState('orden');

    let orden = <h5>No existe ninguna orden de trabajo</h5>;

    if (cliente.length > 0 && vehiculo.length > 0 && servicio.length > 0) {
        orden = (
          <div>
            <hr />
            <h3>Datos del Cliente</h3>
            <hr />
            {cliente.map(cliente => (
                <div>
                    <div>
                        <label>Cliente:</label> 
                        <label>{cliente.nombres}</label> 
                    </div>    
                    <div>
                        <label>Email:</label> 
                        <label>{cliente.email} </label>
                    </div>
                    <div>
                        <label>Celular:</label> 
                        <label>{cliente.celular}</label>
                    </div>
                    <div>
                        <label>Identificacion Fiscal:</label> 
                        <label>{cliente.identificacionFiscal}</label>
                    </div>
                    <div>
                        <label>Tipo de Identificación:</label> 
                        <label>{cliente.tidpid}</label>
                    </div>
                </div>
            ))}
            <hr />
            <h3>Datos del Vehiculo</h3>
            <hr />
            {vehiculo.map(vehiculo => (
                <div>
                    <div>
                        <label>Marca:</label> 
                        <label>{vehiculo.marca}</label> 
                    </div>    
                    <div>
                        <label>Modelo:</label> 
                        <label>{vehiculo.modelo} </label>
                    </div>
                    <div>
                        <label>Placa:</label> 
                        <label>{vehiculo.placa}</label>
                    </div>
                    <div>
                        <label>Gasolina:</label> 
                        <label>{vehiculo.gasolina}</label>
                    </div>
                    <div>
                        <label>Tipo de Identificación:</label> 
                        <label>{vehiculo.defectos}</label>
                    </div>
                </div>
            ))}

            <hr />
            <h3>Servicio Seleccionados</h3>
            <hr />
            {servicio.map(servicio => (
                <div>
                    <div>
                        <label>{servicio.aceite}</label> 
                    </div>    
                    <div>
                        <label>{servicio.frenos} </label>
                    </div>
                    <div>
                        <label>{servicio.balanceo}</label>
                    </div>
                    <div>
                        <label>{servicio.diagnostico}</label>
                    </div>
                    <div>
                        <label>{servicio.electrica}</label>
                    </div>
                    <div>
                        <label>{servicio.suspension}</label>
                    </div>
                </div>
            ))}



          </div>  
        );
    }

const  mostrarComponente = () => {
    return (<div> <Cliente /> </div>)
} 

  //seccion vista
 // if(mostrarComponente === 'cliente') {
 //   return (<div> <Cliente /> </div>)
 // }

    return (
        <div>     
             <form className='form-react' onSubmit=''>
                <h2>Orden de Trabajo</h2>
                {orden}  
                <div className='form-control'>
                    <button type="submit" name='cliente' onClick={mostrarComponente} >Otra Orden{'==>>'}</button>
                </div>               
             </form>
        </div>
    )
}