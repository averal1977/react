import { useState } from 'react';
import { useAppContext } from './AppProvider';
import Vehiculo from './Vehiculo';

const tipoId = ['Cédula', 'Ruc', 'Pasaporte']

export default function Cliente () {
  //seccion declaraciones properties
  const { dispatch } = useAppContext();

  const [nombres, setNombres] = useState('');
  const [email, setEmail] = useState('');
  const [celular, setCelular] = useState('');
  const [identificacionFiscal, setIdentificacionFiscal] = useState('');
  const [tidpid, setTipoIp] = useState('');
  const [mostrarComponente, setMostrarComponente] = useState('cliente');

  //methods
  const handleSubmit = (e) => {
    e.preventDefault();
    //console.log({nombres, email, celular, identificacionFiscal, tidpid})
    //let cliente = {};
    const cliente = { 
      nombres, 
      email, 
      celular, 
      identificacionFiscal, 
      tidpid
    };
    //console.log(cliente); 
    dispatch({
        type: 'ADD_CLIENTE',
        value: cliente  
    });
    setMostrarComponente('vehiculo');
  }
 
  //seccion vista
  if(mostrarComponente === 'vehiculo') {
    return (<div> <Vehiculo /> </div>)
  }

    return (
        <div>
          <form className='form-react' onSubmit={handleSubmit} id="FormCliente">    
              <h2>Datos del Cliente</h2>
              <div className='form-control'>
                  <label htmlFor="nombre">Nombres</label>
                  <input 
                    type="text" 
                    id="nombre" 
                    placeholder=""
                    onChange={(e)=> setNombres(e.target.value)}
                    required
                  />
              </div>
              <div className='form-control'>
                  <label htmlFor="email">Email</label>
                  <input 
                    type="email" 
                    id="email" 
                    placeholder=""
                    onChange={(e)=> setEmail(e.target.value)}
                    required
                  />
              </div>
              <div className='form-control'>
                  <label htmlFor="celular">Celular</label>
                  <input 
                    type="text" 
                    id="celular" 
                    placeholder=""
                    onChange={(e)=> setCelular(e.target.value)}
                    required
                  />
              </div>
              <div className='form-control'>
                  <label htmlFor="identificacion">Identificación Fiscal</label>
                  <input 
                    type="text" 
                    id="identificacion" 
                    placeholder=""
                    onChange={(e)=> setIdentificacionFiscal(e.target.value)}
                    required
                  />
              </div>

              <div className='form-control'>
                <label htmlFor="tipo_id">Tipo de Identificación</label>
                <div className='caja'>
                  <select id='tipo_id' onChange={(e)=> setTipoIp(e.target.value)}>
                    {tipoId.map(item => (
                      <option value={item}>{item}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className='form-control'>
                    <button type="submit" name='vehiculo'>Siguiente{'==>>'}</button>
              </div>  
          </form>     
        </div>
        );
  }