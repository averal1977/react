import { createContext, useReducer, useContext } from "react";

export const AppContext = createContext();
//export const DispatchContext = createContext(null);

export const useAppContext = () => {
    return useContext (AppContext);
}

const initialState = {
    cliente:[],
    vehiculo:[],
    servicio:[]
}

const reducer = (state, action) => {
    //console.log(action);
    switch (action.type) {
        case 'ADD_CLIENTE': {
            return {
                ...state, 
                cliente: [...state.cliente, action.value]
            }
        }

        case 'DEL_CLIENTE': {
            return {
                ...state, 
                cliente: []
            }
        }

        case 'ADD_VEHICULO': {
            return {
                ...state, 
                vehiculo: [...state.vehiculo, action.value]
            }
        }

        case 'DEL_VEHICULO': {
            return {
                ...state, 
                vehiculo: []
            }
        }

        case 'ADD_SERVICIO': {
            return {
                ...state, 
                servicio: [...state.servicio, action.value]
            }
        }

        case 'DEL_SERVICIO': {
            return {
                ...state, 
                servicio: []
            }
        }

    }
    return state;
}


export default function AppProvider ({children}) {
    const [state, dispatch] = useReducer(reducer, initialState);

    return (
        <AppContext.Provider value={{cliente : state.cliente, vehiculo : state.vehiculo, servicio : state.servicio, dispatch}}>
            {children}
        </AppContext.Provider>
    )
}