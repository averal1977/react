import { useState } from 'react';
import { useAppContext } from './AppProvider';
import { useAppContextUi } from './AppProviderUi';

export default function Servicio () {
  //seccion declaraciones properties
  const { systemcar, dispatch } = useAppContext();
  const { dispatch: dispatchUi } = useAppContextUi();    

  const [aceite, setAceite] = useState(systemcar.servicio.aceite);
  const [frenos, setFrenos] = useState(systemcar.servicio.frenos);
  const [balanceo, setBalanceo] = useState(systemcar.servicio.balanceo);
  const [diagnostico, setDiagnostico] = useState(systemcar.servicio.diagnostico);
  const [electrica, SetElectrica] = useState(systemcar.servicio.electrica);
  const [suspension, Setsuspension] = useState(systemcar.servicio.suspension);

  //methods
  const handleSubmit = (e) => {
    e.preventDefault();
   const servicio = { 
      aceite, 
      frenos, 
      balanceo, 
      diagnostico, 
      electrica,
      suspension
    };
    dispatch({
        type: 'ADD_SERVICIO',
        value: servicio
    });
    dispatchUi({
      type: 'setForm',
      value: 4 
    });   
  }

  const handleRegresar = () => {
    dispatchUi({
        type: 'setForm',
        value: 2,
    })
}

//seccion vista
return (
        <form className='form-react'>
          <h2>Tipo de Servicios</h2>
          <div className='form-react'>
              <label for="tiposervicio">Seleccione el tipo de servicio a realizar:</label>
              <div class="linea">
                <input type="checkbox" 
                  name="aceite" 
                  id="aceite"
                  onChange={(e)=> setAceite( (e.target.checked) ? "Cambio de aceite" : '')}
                />
                <label for="aceite">Cambio de aceite</label>
              </div>
              <div class="linea">
                <input 
                  type="checkbox" 
                  name="frenos" 
                  id="frenos"
                  onChange={(e)=> setFrenos( (e.target.checked) ? "Cambio de frenos" : '')}
                />
                <label for="frenos">Cambio de frenos</label>
              </div>

              <div class="linea">
                <input 
                  type="checkbox" 
                  name="balanceo" 
                  id="balanceo"
                  onChange={(e)=> setBalanceo( (e.target.checked) ? "Alineación y balanceo" : '')}
                />
                <label for="balanceo">Alineación y balanceo</label>  
              </div>

              <div class="linea">
                <input 
                  type="checkbox" 
                  name="diagnostico" 
                  id="diagnostico"
                  onChange={(e)=> setDiagnostico( (e.target.checked) ? "Diagnóstico general" : '')}
                />
                <label for="diagnostico">Diagnóstico general</label>  

              </div>
              <div class="linea">
                <input 
                  type="checkbox" 
                  name="electrica" 
                  id="electrica"
                  onChange={(e)=> SetElectrica( (e.target.checked) ? "Revisión sistema eléctrica" : '')}
                  />
                <label for="electrica">Revisión sistema eléctrica</label>  
              </div>

              <div class="linea">
                <input 
                  type="checkbox" 
                  name="suspension" 
                  id="suspension"
                  onChange={(e)=> Setsuspension( (e.target.checked) ? "Revisión de la suspensión" : '')}
                />
                <label for="suspension">Revisión de la suspensión</label>  
              </div>              
          </div> 
          <div className='form-control'>
            <button type="submit" name='vehiculo' onClick={handleRegresar}> {'<<=='}Regresar </button>
            <hr color='black'/>
            <button type="submit" name='orden' onClick={handleSubmit}> Generar orden{'==>>'} </button>
         </div>   

        </form>
    );
}