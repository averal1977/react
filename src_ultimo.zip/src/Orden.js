import { useAppContext } from "./AppProvider";
import { useAppContextUi } from './AppProviderUi';


export default function Orden () {
    //seccion declaraciones properties
    const { systemcar, dispatch } = useAppContext();
    const { dispatch: dispatchUi } = useAppContextUi();    

    let today = new Date();
    today.setDate(today.getDate()+2).toLocaleString();
    let now = today.toLocaleString();

    const {nombres, email, celular, identificacionFiscal, tipoid} = systemcar.cliente;
    const {marca, modelo,  placa, gasolina, defectos} = systemcar.vehiculo;
    const {aceite, frenos, balanceo, diagnostico, electrica, suspension} = systemcar.servicio;     


    let orden = <h5>No existe ninguna orden de trabajo</h5>;

        orden = (
          <div>
            <hr />
            <h3>Datos del Cliente</h3>
            <hr />
                <div>
                    <div>
                        <label>Cliente:  </label> 
                        <label>{nombres}</label> 
                    </div>    
                    <div>
                        <label>Email:  </label> 
                        <label>{email} </label>
                    </div>
                    <div>
                        <label>Celular:  </label> 
                        <label>{celular}</label>
                    </div>
                    <div>
                        <label>Identificacion Fiscal:  </label> 
                        <label>{identificacionFiscal}</label>
                    </div>
                    <div>
                        <label>Tipo de Identificación:  </label> 
                        <label>{tipoid}</label>
                    </div>
                </div>

            <hr />
            <h3>Datos del Vehiculo</h3>
            <hr />
                <div>
                    <div>
                        <label>Marca:  </label> 
                        <label>{marca}</label> 
                    </div>    
                    <div>
                        <label>Modelo:  </label> 
                        <label>{modelo} </label>
                    </div>
                    <div>
                        <label>Placa:  </label> 
                        <label>{placa}</label>
                    </div>
                    <div>
                        <label>Gasolina:  </label> 
                        <label>{gasolina}</label>
                    </div>
                    <div>
                        <label>Tipo de Identificación:  </label> 
                        <label>{defectos}</label>
                    </div>
                </div>

            <hr />
            <h3>Servicio Seleccionados</h3>
            <hr />
                <div>
                    <div>
                        <label>{aceite}</label> 
                    </div>    
                    <div>
                        <label>{frenos} </label>
                    </div>
                    <div>
                        <label>{balanceo}</label>
                    </div>
                    <div>
                        <label>{diagnostico}</label>
                    </div>
                    <div>
                        <label>{electrica}</label>
                    </div>
                    <div>
                        <label>{suspension}</label>
                    </div>
                </div>

            <hr />
            <h3>Datos de Entrega y Aprobacion</h3>
            <hr />
            <div>
                <label>Fecha y Hora de Entrega:  </label> 
                <label>{now}</label>
            </div>
            <div>
                <br />
                <label>Firma de Aprobación del Cliente:</label> 
                <label>-----------------FIRMA-----------------</label>
                <br />
                <br />
            </div>

          </div>  
        );


const handleRegresar = () => {
    dispatch({
        type: 'RESET'
    });        
    dispatchUi({
        type: 'setForm',
        value: 1,
    })
}



//seccion vista    
    return (
        <div>     
             <form className='form-react'>
                <h2>Orden de Trabajo</h2>
                {orden}  
                <div className='form-control'>
                    <button type="submit" name='cliente' onClick={handleRegresar} >Otra Orden{'==>>'}</button>
                </div>               
             </form>
        </div>
    )
}