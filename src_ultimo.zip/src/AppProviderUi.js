import { createContext, useContext, useReducer } from "react";

//--------------------------------------------------------
//Context
//--------------------------------------------------------

export const AppContextUi = createContext({});


export const AppProviderUi = ({ children }) => {
    const [menu, dispatch] = useReducer(reducerui, initialStateui);

    return (
        <AppContextUi.Provider value={{ menu, dispatch }}>
            {children}
        </AppContextUi.Provider>
    )
}

export const useAppContextUi = () => {
    return useContext (AppContextUi);
}

//--------------------------------------------------------
//Reducer
//--------------------------------------------------------
export const initialStateui = {
    loading: false,
    darkMode: false,
    component: 1
}


export const reducerui = (state = initialStateui, action) => {
    switch (action.type) {
        case 'setDarkMode':
            return {
                ...state,
                darkMode: action.value
            }
        case 'setForm':
            return {
                ...state,
                component: action.value
            }
        case 'startLoading':
            return {
                ...state,
                loading: true
            }
        case 'finishLoading':
            return {
                ...state,
                loading: false
            }
        default:
            return state;
    }

}
